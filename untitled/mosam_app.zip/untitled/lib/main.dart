import 'package:flutter/material.dart';

import 'activity/home.dart';
import 'activity/location.dart';
import 'activity/loding.dart';
void main() {
  runApp(
    MaterialApp(

      routes: {
        '/':  (context)=> loding(),
        '/home':(context)=> home(),
        '/loading':(context)=> loding()
      },
    )
  );
}

